#!/bin/sh

/sbin/iw dev wlan0 set power_save off
